"""Report fixed-architecture loss/activation selection, without test scoring."""
import json

from experiments.CelebA.selection_report import (
    METRICS, _aggregate, _csv, _plots, _split_accounting, _table, _validate,
)


def build_report(output, protocol, rows, selected):
    cfg = protocol['config']
    _validate(rows)
    summaries = _aggregate(rows, cfg['repeats'], 'selection')
    _csv(output / 'per_fit.csv', rows, ('representation', 'branch', 'candidate', 'repeat') + METRICS)
    _csv(output / 'per_candidate.csv', summaries, ('representation', 'branch', 'candidate', 'repeats'))
    plots = _plots(output, summaries, cfg, selected)
    complete = len(rows) == len(protocol['tasks']) and selected is not None
    status = dict(complete=complete, baseline_fits=len(rows), expected_baseline_fits=len(protocol['tasks']),
                  scope='loss_and_activation_selection_only', test_assets_loaded=False,
                  architecture_selection=False, final_assessment=False)
    lines = ['# CelebA expanded-data loss and activation selection', '',
             f"**Status: {'complete' if complete else 'incomplete'}; {len(rows)}/{len(protocol['tasks'])} verified fits.**", '',
             'Fixed baseline architectures; four losses, four sigmoid slopes, five paired repetitions. '
             'Separate selections for both P/Q pairs and both representations. The output is r=2 sigmoid(alpha z).', '',
             'Checkpoints minimize stopping-set balanced Brier. Selection uses the paired one-SE Brier shortlist, '
             'then minimum supported local absolute Gap, with at least 0.99 supported mass in every repetition. '
             'Calibration and evaluation rows for selection are separate. P and Q each have weight one half.', '',
             'Hellinger backward uses an algebraic exponential scale factor and float64 gradient norms. '
             'The factor is accounted for during gradient clipping; the objective and ratio parameterization '
             'are unchanged, with no ratio clipping.', '',
             'Architecture sensitivity and final calibration/evaluation are outside this run. '
             'Final image/feature arrays remain unopened by this model-selection workflow.', '',
             '## Selected settings', '', '| Representation / pair | Loss | Sigmoid slope |', '| --- | --- | --- |']
    for level in cfg['levels']:
        for branch in cfg['branches']:
            choice = (selected or {}).get('selections', {}).get(f'{level}/{branch}', {}).get('chosen', {})
            lines.append(f"| {level} / {branch} | {choice.get('loss', 'Pending')} | {choice.get('output_alpha', 'Pending')} |")
    lines += ['', '## Exact split counts', '', *_split_accounting(output, protocol), '',
              '## Validation results', '', 'Entries show mean (SD) over the five registered repetitions. '
              'Incomplete candidates are not averaged over fewer runs.', '',
              *_table(summaries, ('brier', 'local_gap', 'supported_mass')), '',
              *_table(summaries, ('middle_mass', 'middle_supported_fraction', 'middle_local_gap'))]
    for stem in plots:
        lines += ['', f'![Brier and local Gap]({stem}.png)']
    lines += ['', 'Repetitions measure initialization/training-order variation conditional on these data. '
              'Local score-cell intervals remain nominal image-level diagnostics. Previously inspected '
              'historical data make this a retrospective study.', '',
              '[Per-fit metrics](per_fit.csv) · [Per-candidate metrics](per_candidate.csv) · '
              '[Protocol](protocol.json) · [Selected settings](baseline_selection.json)', '']
    (output / 'RESULTS.md').write_text('\n'.join(lines))
    (output / 'report_status.json').write_text(json.dumps(status, indent=2) + '\n')
    return status

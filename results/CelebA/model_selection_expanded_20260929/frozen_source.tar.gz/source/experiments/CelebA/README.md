# CelebA model selection

The active study compares real P against Q_L and Q_U from the fixed
Diffusion-StyleGAN2 CelebA64 generator (truncation 0.650 and 1.569). Each pair
has its own fitted network. Feature and pixel representations are studied
separately. Historical workflows and results are retained; see the
[dataset inventory](../../docs/CelebA.md).

## Registered study

The separate [expanded-pool FID check](expanded_fid.md) assesses the proposed
larger sample pools with fixed generator settings. It does not change this
running 60k model-selection study.

[selection_config.json](selection_config.json) specifies four losses
(Hellinger, KL, chi-square, JS), four output slopes (0.5, 1, 2, 4), and five
paired repetitions. The RDR is `2 sigmoid(alpha*z)` and targets `2p/(p+q)`.
The two pairs and two representations require **320 baseline fits**.

- Feature baseline: frozen 2048-D Inception pool3, three hidden ReLU layers
  of width 512, raw scalar head. Standardization is fitted on pooled training
  P and Q separately for each pair and reused across candidates and roles.
- Pixel baseline: the existing RGB64 DCGAN-style CNN, base width 64,
  BatchNorm/LeakyReLU, and raw scalar head. Stored uint8 pixels map to [-1,1].
- The architecture sensitivity uses the same structures with feature width
  256 and CNN base width 32. This checks width sensitivity, not every possible
  architectural family.

Feature optimization retains AdamW, weight decay .01, and the plateau
scheduler; pixel optimization retains Adam, OneCycle, and BatchNorm freezing
from zero-based epoch 5. All source observations are used once per epoch,
including unequal final batches. The maximum is 50 epochs. Brier, rather than
the candidate-specific objective, controls checkpoints, stopping and the
feature plateau scheduler. Losses use stable logit expressions with the same
midpoint weights; the new Hellinger fit has no historical ratio clipping.
Consequently this study is a fresh comparison, not a reproduction of old
Hellinger checkpoints. A fixed training subset supplies training-Brier curves.

Initialization, training orders and diagnostic subsets are paired across
candidates and both contrasts. Samples are fixed across all five repeats;
repeat SEs describe algorithmic variation conditional on these samples, not
uncertainty across independent datasets or generated pools.

## Data roles

Keep all historical 60,000 training rows per source. Divide the historical
20,000 validation rows into half for stopping and quarters for selection
calibration and selection evaluation. Real identities stay together, so exact
image counts can differ slightly from 10,000/5,000/5,000. Generated roles have
exactly those sizes and disjoint seeds. The same P roles serve both contrasts.
Balanced metrics weight P and Q by one half despite unequal counts.

With registered split seed `2026092902`, the audited counts are:

| Role | P images | P identities | Each Q branch |
| --- | ---: | ---: | ---: |
| Training | 60,000 | 6,057 | 60,000 |
| Stopping | 9,995 | 1,005 | 10,000 |
| Selection calibration | 4,998 | 500 | 5,000 |
| Selection evaluation | 5,007 | 496 | 5,000 |
| Test calibration | 9,002 | 994 | 9,000 |
| Test evaluation | 8,998 | 960 | 9,000 |

The historically inspected design/test union contains 18,000 rows per source.
It is divided into calibration and evaluation halves, again preserving real
identities. Preparation reads its manifests to verify disjointness but does
not read its features or images. Test assets are loaded only after every
selection stage has completed and the final choice is frozen. The final report
shows both whole-test Brier and independent-evaluation Brier. Historical use
of validation and test data makes this a retrospective study.

Local Gap uses the existing 20 equal-width bins on [0,2]. Calibration rows
estimate true cell-average RDR; separate evaluation rows estimate neural cell
means and mixture masses. CIs remain nominal image-level diagnostics, with
no adjustment for repeated photos within identity, candidate selection, or
neural-mean sampling uncertainty. They do not establish pointwise accuracy.
All cells, unsupported mass and middle-region mass/Gap are retained.

## Selection and the limited architecture check

1. For each pair and representation, choose checkpoints by minimum stopping
   Brier. On selection evaluation, form the paired one-SE Brier shortlist;
   require supported mass at least .99 in every repetition, then minimize
   mean local absolute Gap (ties: Brier, candidate ID).
2. Take the union across both pairs of their Brier reference and selected
   setting. If these coincide, add the next support-eligible setting by mean
   Brier. Fit the narrower architecture on this same union for both pairs.
   This adds 40--80 fits across the two representations in the full study.
3. Expand the narrower architecture to the full loss/slope grid for both
   pairs of a representation only if an alternative has .99 support in every
   repeat and improves over the corresponding baseline-selected model by
   at least .002 mean Brier, more than one paired SE, with improvement in at
   least 80% of repeats. These are prespecified practical heuristics, not a
   significance test. Already completed sensitivity fits are reused.
4. Without that trigger the baseline selection remains primary. If expanded,
   apply the same BS/Gap rule to the complete baseline-plus-narrower grid.
   Report the intersection of eligible settings across pairs as a descriptive
   common-configuration option. Test scores never enter these decisions.

## Commands and prerequisites

Use the existing Python 3.9/PyTorch 2.6 environment, with NumPy, pandas, SciPy,
matplotlib and Pillow. The current input adapter requires the recorded
historical split locks, source manifests, Inception feature caches, selected
real uint8 caches and generated image shards. No old learned RDR checkpoint
or prediction is needed. Input hashes, row alignment, identities, generated
seeds, truncation and synthesis noise are checked before use.

Run from the repository root, using a new output directory:

```bash
python3 -B experiments/CelebA/model_selection.py prepare \
  --output /cwork/yx306/RDR/CelebA/model_selection_20260929
python3 -B /cwork/yx306/RDR/CelebA/model_selection_20260929/source/experiments/CelebA/model_selection.py submit \
  --output /cwork/yx306/RDR/CelebA/model_selection_20260929 --concurrency 4
```

Submission starts separate feature/pixel GPU arrays with at most four active
tasks each. CPU jobs depend on successful completion of both arrays, verify
all receipts, register the next stage and submit it. This continues through
sensitivity, any triggered expansion, final assessment and reporting.
`selection.slurm` specifies the mastatlab account/partition; adapt it before
preparing a snapshot for another cluster. `RDR_PYTHON` selects the interpreter.
Stages reject missing/corrupt fits and duplicate submissions. Failed-fit
directories are preserved for diagnosis rather than silently discarded.

Without Slurm, use the same prepared snapshot with `run --device cuda`, or
invoke individual `fit`, `advance`, `evaluate` and `report` commands. For a
bounded CPU integration run using actual archived inputs:

```bash
python3 -B experiments/CelebA/model_selection.py prepare \
  --output /tmp/celeba-selection-smoke --smoke
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  python3 -B /tmp/celeba-selection-smoke/source/experiments/CelebA/model_selection.py run \
  --output /tmp/celeba-selection-smoke --device cpu
```

`--source-root` relocates the main archive. For other recorded external roots,
add a `path_map` mapping old absolute prefixes to new prefixes in a custom JSON
config, then prepare with `--config`. Prepared array/manifest paths are relative
to the run directory. Data acquisition and the historical generator training
membership are separate from this archived-input workflow.

## Artifacts and verification

Each run freezes its executing source, configuration, split manifests and data
receipts. Use its saved entrypoint after repository source changes. Arrays are
memory mapped; source caches are hashed during preparation. Each fit verifies
the sealed protocol plus prepared array size/mtime/schema, and writes hashed
checkpoint/prediction/metric completion receipts. `verify_receipt(full=True)`
supports independent full array hashing. Final choices seal selected fit
receipts before test access. Scientific outputs remain outside Git.

- `protocol.json`, `data/metadata.json`: registered choices and exact source roles.
- `baseline_selection.json`, `sensitivity_tasks.json`, `expansion.json`,
  optional `expanded_tasks.json`, `freeze.json`: completion-gated decisions.
- `fits/`: checkpoints, selection scores, cell diagnostics and training histories.
- `evaluation/`: selected frozen-model retrospective assessments.
- `RESULTS.md`, `per_fit.csv`, `per_candidate.csv`, plots and
  `report_status.json`: results with explicit pending/completed counts.
- `jobs/`, `logs/`: Slurm submission records and task/controller logs.
- `COMPLETE.json`: written only after the full report verifies every required
  fit and selected assessment. Its absence means the study is incomplete.

```bash
OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 \
  python3 -B -m pytest -q -p no:cacheprovider tests/test_celeba_model_selection.py \
  tests/test_celeba_selection_data.py tests/test_celeba_selection_training.py \
  tests/test_celeba_selection_report.py
```

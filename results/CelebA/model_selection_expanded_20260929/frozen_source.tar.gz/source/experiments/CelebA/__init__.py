"""CelebA experiment-specific components."""
